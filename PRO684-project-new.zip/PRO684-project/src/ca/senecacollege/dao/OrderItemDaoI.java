package ca.senecacollege.dao;

public interface OrderItemDaoI {

}
