package ca.senecacollege.dao;


public interface ProductDaoI {
	
}
