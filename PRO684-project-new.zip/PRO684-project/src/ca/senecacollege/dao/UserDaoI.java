package ca.senecacollege.dao;

import ca.senecacollege.model.User;

public interface UserDaoI extends BaseDaoI<User> {
	
}
