package ca.senecacollege.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ca.senecacollege.dao.OrderItemDaoI;
import ca.senecacollege.model.OrderItem;
import ca.senecacollege.model.Product;
import ca.senecacollege.model.User;
import ca.senecacollege.util.DBUtil;

public class OrderItemDaoImpl implements OrderItemDaoI{

	DBUtil dbUtil = new DBUtil();
	OrderItem orderItem= new OrderItem();
	List<OrderItem> orderItems= new ArrayList<OrderItem>();
	
	public int add(OrderItem OrderItem) {
		String sql = "insert into OrderItem(purchasedate,userid,productid) values(?,?,?)";
		List<Object> params = new ArrayList<Object>();
		params.add(OrderItem.getPurchasedate());
		params.add(OrderItem.getUser().getId());
		params.add(OrderItem.getProduct().getId());
		return dbUtil.executeOperate(sql,params);
	}

	public OrderItem findById(int id) {
		String sql ="select * from OrderItem where id=?";
		List<Object> params = new ArrayList<Object>();
		params.add(id);
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				orderItem.setId(rs.getInt("id"));
				orderItem.setPurchasedate(rs.getDate("purchasedate"));
				User user = new UserDaoImpl().findById(rs.getInt("id"));
				orderItem.setUser(user);
				Product product = new ProductDaoImpl().findById(rs.getInt("id"));;
				orderItem.setProduct(product);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return orderItem;
	}

	public List<OrderItem> findAll() {
		String sql ="select * from OrderItem";
		List<Object> params = new ArrayList<Object>();
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				OrderItem orderItem = new OrderItem();
				orderItem.setId(rs.getInt("id"));
				User user = new UserDaoImpl().findById(rs.getInt("id"));
				orderItem.setUser(user);
				Product product = new ProductDaoImpl().findById(rs.getInt("id"));
				orderItem.setProduct(product);
				orderItems.add(orderItem);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return orderItems;

	}

	public int delete(int id) {
		OrderItem orderItem = findById(id);
		if (orderItem.getPurchasedate() ==null) {
			return -1;
		}else {
			
			String sql = "delete from orderitem where id=?";
			List<Object> params = new ArrayList<Object>();
			params.add(orderItem.getId());
			return dbUtil.executeOperate(sql,params);	
		}
	}

	public int update(OrderItem t) {
		String sql = "update orderitem set purchasedate=?, userid=?, productid=? where id=?";
		List<Object> params = new ArrayList<Object>();			
		params.add(orderItem.getPurchasedate());
		params.add(orderItem.getUser().getId());
		params.add(orderItem.getProduct().getId());
		params.add(orderItem.getId());
		return dbUtil.executeOperate(sql,params);	
	}








}
