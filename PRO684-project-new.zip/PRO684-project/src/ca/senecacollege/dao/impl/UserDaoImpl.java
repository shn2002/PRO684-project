package ca.senecacollege.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ca.senecacollege.dao.UserDaoI;
import ca.senecacollege.model.User;
import ca.senecacollege.util.DBUtil;

public class UserDaoImpl implements UserDaoI{

	DBUtil dbUtil = new DBUtil();
	User user= new User();
	List<User> users= new ArrayList<User>();
	
	public int add(User user) {
		String sql = "insert into user(username,password,cellphone,email,address,is_admin) values(?,?,?,?,?,?)";
		List<Object> params = new ArrayList<Object>();
		params.add(user.getUsername());
		params.add(user.getPassword());
		params.add(user.getCellphone());
		params.add(user.getEmail());
		params.add(user.getAddress());
		params.add(user.getIsadmin());
		return dbUtil.executeOperate(sql,params);
	}

	public User findById(int id) {
		String sql ="select * from user where id=?";
		List<Object> params = new ArrayList<Object>();
		params.add(id);
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setAddress(rs.getString("address"));
				user.setIsadmin(rs.getString("is_admin"));
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return user;
	}

	public List<User> findAll() {
		String sql ="select * from user";
		List<Object> params = new ArrayList<Object>();
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setAddress(rs.getString("address"));
				user.setIsadmin(rs.getString("is_admin"));
				users.add(user);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return users;

	}

	public int delete(int id) {
		User user = findById(id);
		if (user.getUsername() ==null) {
			return -1;
		}else {
			
			String sql = "delete from user where id=?";
			List<Object> params = new ArrayList<Object>();
			params.add(user.getId());
			return dbUtil.executeOperate(sql,params);	
		}
	}

	public int update(User t) {
		String sql = "update FRIENDS set username=?, password=?, cellphone=?, email=? , address=?, is_admin=? where id=?";
		List<Object> params = new ArrayList<Object>();			
		params.add(user.getUsername());
		params.add(user.getPassword());
		params.add(user.getCellphone());
		params.add(user.getEmail());
		params.add(user.getAddress());
		params.add(user.getIsadmin());
		return dbUtil.executeOperate(sql,params);	
	}








}
