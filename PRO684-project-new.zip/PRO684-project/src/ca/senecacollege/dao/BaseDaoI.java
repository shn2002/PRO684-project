package ca.senecacollege.dao;

import java.util.List;


public interface BaseDaoI<T> {
	T findById(int id); 
	List<T> findAll(); 
	int delete(int id);
	int update(T t);
	int add(T t); 
}
