package ca.senecacollege.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ca.senecacollege.dao.FriendDao;
import ca.senecacollege.model.Friend;
import ca.senecacollege.util.DBUtil;

public class FriendDaoImpl implements FriendDao {
	DBUtil dbUtil = new DBUtil();
	Friend friend= new Friend();
	List<Friend> friends= new ArrayList<Friend>();
	
	public int addFriend(Friend Friend) {
		String sql = "insert into FRIENDS(friendName,emailAddress,age,favoriteColor) values(?,?,?,?)";
		List<Object> params = new ArrayList<Object>();
		params.add(Friend.getFriendName());
		params.add(Friend.getEmailAddress());
		params.add(Friend.getAge());
		params.add(Friend.getFavoriteColor());
		return dbUtil.executeOperate(sql,params);
	}


	public Friend findById(int id)  {
		String sql ="select * from FRIENDS where FriendID=?";
		List<Object> params = new ArrayList<Object>();
		params.add(id);
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				friend.setFriendID(rs.getInt("FRIENDID"));
				friend.setFriendName(rs.getString("friendName"));
				friend.setEmailAddress(rs.getString("emailAddress"));
				friend.setAge(rs.getInt("age"));
				friend.setFavoriteColor(rs.getString("favoriteColor"));
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return friend;
	}


	public List<Friend> findAll() {
		String sql ="select * from FRIENDS";
		List<Object> params = new ArrayList<Object>();
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				Friend friend = new Friend();
				friend.setFriendID(rs.getInt("FRIENDID"));
				friend.setFriendName(rs.getString("friendName"));
				friend.setEmailAddress(rs.getString("emailAddress"));
				friend.setAge(rs.getInt("age"));
				friend.setFavoriteColor(rs.getString("favoriteColor"));
				friends.add(friend);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return friends;
	}


	@Override
	public int deleteFriend(int id) {
		Friend friend = findById(id);
		if (friend.getFriendName() ==null) {
			return -1;
		}else {
			
			String sql = "delete from FRIENDS where FriendID=?";
			List<Object> params = new ArrayList<Object>();
			params.add(friend.getFriendID());
			return dbUtil.executeOperate(sql,params);	
		}
	}


	@Override
	public int updateFriend(Friend friend) {		
			String sql = "update FRIENDS set friendName=?, emailAddress=?, age=?, favoriteColor=? where FriendID=?";
			List<Object> params = new ArrayList<Object>();			
			params.add(friend.getFriendName());
			params.add(friend.getEmailAddress());
			params.add(friend.getAge());
			params.add(friend.getFavoriteColor());
			params.add(friend.getFriendID());
			
			return dbUtil.executeOperate(sql,params);	
	}


}
