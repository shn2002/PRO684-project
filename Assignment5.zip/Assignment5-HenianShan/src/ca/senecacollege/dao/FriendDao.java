package ca.senecacollege.dao;

import java.util.List;
import ca.senecacollege.model.Friend;

public interface FriendDao {
	int addFriend(Friend friend); 
	Friend findById(int id); 
	List<Friend> findAll(); 
	int deleteFriend(int id);
	int updateFriend(Friend friend);
}
