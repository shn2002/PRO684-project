package ca.senecacollege.util;

public class ValidationUtil {
	private String message;
	private boolean flag=true;
	private int number;
	
	public String getMessage() {
		return message;
	}

	public boolean isFlag() {
		return flag;
	}

	public int getNumber() {
		return number;
	}

	public ValidationUtil stringVal(String name,String variable) {
		ValidationUtil vu = new ValidationUtil();
		if(variable == null||variable.isEmpty()) {
			vu.flag=false;
			vu.message=name+" should not be blank; ";
		}
		return vu;
	}
	public ValidationUtil intVal(String name,String variable) {
		ValidationUtil vu = new ValidationUtil().stringVal(name, variable);
		if (vu.isFlag()) {
			try {
				int number = Integer.parseInt(variable);
				vu.number=number;
				vu.message=null;
			} catch (NumberFormatException e) {
				vu.message=name+" is not a number; ";
				vu.flag=!vu.isFlag();
			}
			
		}
		return vu;
	}	
	
}
