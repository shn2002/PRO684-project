package ca.senecacollege.model;

import java.util.Date;
import java.util.Set;

public class OrderItem {
	private int id;
	private Date purchasedate;
	private User user;
	private Set<Product> products;
	
	public OrderItem(int id, Date purchasedate, User user, Set<Product> products) {
		super();
		this.id = id;
		this.purchasedate = purchasedate;
		this.user = user;
		this.products = products;
	}
	public OrderItem() {}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(Date purchasedate) {
		this.purchasedate = purchasedate;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Set<Product> getProducts() {
		return products;
	}
	public void setProducts(Set<Product> products) {
		this.products = products;
	}
	
}
