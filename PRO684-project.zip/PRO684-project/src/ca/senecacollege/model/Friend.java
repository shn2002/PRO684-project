package ca.senecacollege.model;

public class Friend {
	private int friendID;
	private String friendName;
	private String emailAddress;
	private int age;
	private String favoriteColor;
	
	public Friend(String friendName, String emailAddress, int age, String favoriteColor) {
		super();
		this.friendName = friendName;
		this.emailAddress = emailAddress;
		this.age = age;
		this.favoriteColor = favoriteColor;
	}
	
	public Friend() {}
	
	public int getFriendID() {
		return friendID;
	}
	public void setFriendID(int friendID) {
		this.friendID = friendID;
	}
	public String FriendName() {
		return friendName;
	}
	public void setFriendName(String friendName) {
		this.friendName = friendName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getFavoriteColor() {
		return favoriteColor;
	}
	public void setFavoriteColor(String favoriteColor) {
		this.favoriteColor = favoriteColor;
	}

	public String getFriendName() {
		return friendName;
	}


	

}
