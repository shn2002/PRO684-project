package ca.senecacollege.util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;


public class DBUtil {

	private static String driver ; 
	private static String url; 
	private static String username; 
	private static String password;
	private static PropertyUtil props = new PropertyUtil();
	
	static{
		//InputStream is = DBUtil.class.getClassLoader().getResourceAsStream("dbConn.properties");
		try {
			//props.load(is);
			//driver = props.getProperty("driver");
			//url = props.getProperty("url");
			//username = props.getProperty("username");
			//password = props.getProperty("password");
			//driver="com.mysql.cj.jdbc.Driver";
			//url="jdbc:mysql://localhost:3306/As5_HenianShan";
			//username="root";
			//password="admin";
			driver=props.getDriver();
			url=props.getUrl();
			username=props.getUsername();
			password=props.getPassword();
			
			
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
	}
	
	public static Connection getConnection (){
		try {
			Connection connection = DriverManager.getConnection(url, username, password);
			return  connection; 
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	public ResultSet executeQuery(String sql, List<Object> params)
	{
		Connection conn = null;
		PreparedStatement preStmt = null;
		ResultSet res = null;
 
		try
		{
			conn = getConnection();
			preStmt = conn.prepareStatement(sql);
			setParams(preStmt, params);
			res = preStmt.executeQuery();
 
		} catch (SQLException sqle)
		{
			sqle.printStackTrace();
			closeResource(res, preStmt, conn);
		}
 
		return res;
	}

	public int executeOperate(String sql)
	{
		int count = 0;
		Connection conn = null;
		PreparedStatement preStmt = null;
 
		try
		{
			conn = getConnection();
			preStmt = conn.prepareStatement(sql);
			count = preStmt.executeUpdate();
 
		} catch (SQLException sqle)
		{
			sqle.printStackTrace();
		} finally
		{
			closeResource(preStmt, conn);
		}
 
		return count;
	}
	public int executeOperate(String sql, List<Object> params)
	{
		int count = 0;
		Connection conn = null;
		PreparedStatement preStmt = null;
 
		try
		{
			conn = getConnection();
			preStmt = conn.prepareStatement(sql);
			setParams(preStmt, params);
			count = preStmt.executeUpdate();
 
		} catch (SQLException sqle)
		{
			sqle.printStackTrace();
		} finally
		{
			closeResource(preStmt, conn);
		}
 
		return count;
	}

	public void closeResource(Statement stmt, Connection conn)
	{
		try
		{
			if (stmt != null)
			{
				stmt.close();
			}
 
			if (conn != null)
			{
				conn.close();
			}
 
		} catch (SQLException sqle)
		{
			sqle.printStackTrace();
		}
	}
	
	public void closeResource(ResultSet res, Statement stmt, Connection conn)
	{
		try
		{
			if (res != null)
			{
				res.close();
			}
 
			if (stmt != null)
			{
				stmt.close();
			}

			if (conn != null)
			{
				conn.close();
			}
 
		} catch (SQLException sqle)
		{
			sqle.printStackTrace();
		}
	}
	public void setParams(PreparedStatement preStmt, List<Object> params) throws SQLException
	{
		if (params != null && params.size() > 0)
		{
			for (int i = 0; i < params.size(); i++)
			{
				preStmt.setObject(i + 1, params.get(i));
			}
		}
	}

	
	
}
