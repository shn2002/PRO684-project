package ca.senecacollege.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ca.senecacollege.dao.OrderItemDaoI;
import ca.senecacollege.model.OrderItem;
import ca.senecacollege.model.Product;
import ca.senecacollege.model.User;
import ca.senecacollege.util.DBUtil;

public class OrderItemDaoImpl implements OrderItemDaoI{

	DBUtil dbUtil = new DBUtil();
	OrderItem OrderItem= new OrderItem();
	User user = new User();
	Product product = new Product();
	List<OrderItem> OrderItems= new ArrayList<OrderItem>();
	
	public int add(OrderItem OrderItem) {
		String sql = "insert into OrderItem(purchasedate,userid,productid) values(?,?,?)";
		List<Object> params = new ArrayList<Object>();
		params.add(OrderItem.getPurchasedate());
		return dbUtil.executeOperate(sql,params);
	}

	public OrderItem findById(int id) {
		String sql ="select * from OrderItem where id=?";
		List<Object> params = new ArrayList<Object>();
		params.add(id);
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				OrderItem.setId(rs.getInt("id"));
				OrderItem.setPurchasedate(rs.getDate("purchasedate"));
				User user = new UserDaoImpl().findById(rs.getInt("id"));
				OrderItem.setUser(user);
				OrderItem.setAddress(rs.getString("address"));
				OrderItem.setIsadmin(rs.getString("is_admin"));
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return OrderItem;
	}

	public List<OrderItem> findAll() {
		String sql ="select * from OrderItem";
		List<Object> params = new ArrayList<Object>();
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				OrderItem OrderItem = new OrderItem();
				OrderItem.setId(rs.getInt("id"));
				OrderItem.setOrderItemname(rs.getString("OrderItemname"));
				OrderItem.setPassword(rs.getString("password"));
				OrderItem.setEmail(rs.getString("email"));
				OrderItem.setAddress(rs.getString("address"));
				OrderItem.setIsadmin(rs.getString("is_admin"));
				OrderItems.add(OrderItem);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return OrderItems;

	}

	public int delete(int id) {
		OrderItem OrderItem = findById(id);
		if (OrderItem.getOrderItemname() ==null) {
			return -1;
		}else {
			
			String sql = "delete from OrderItem where id=?";
			List<Object> params = new ArrayList<Object>();
			params.add(OrderItem.getId());
			return dbUtil.executeOperate(sql,params);	
		}
	}

	public int update(OrderItem t) {
		String sql = "update FRIENDS set OrderItemname=?, password=?, cellphone=?, email=? , address=?, is_admin=? where id=?";
		List<Object> params = new ArrayList<Object>();			
		params.add(OrderItem.getOrderItemname());
		params.add(OrderItem.getPassword());
		params.add(OrderItem.getCellphone());
		params.add(OrderItem.getEmail());
		params.add(OrderItem.getAddress());
		params.add(OrderItem.getIsadmin());
		return dbUtil.executeOperate(sql,params);	
	}








}
