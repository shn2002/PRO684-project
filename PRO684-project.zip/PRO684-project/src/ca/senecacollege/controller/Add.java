package ca.senecacollege.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ca.senecacollege.dao.impl.FriendDaoImpl;
import ca.senecacollege.model.Friend;
import ca.senecacollege.util.ValidationUtil;

/**
 * Servlet implementation class Add
 */
//@WebServlet("/Add")
public class Add extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Add() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String age = request.getParameter("age");	
		String email = request.getParameter("email");	
		String color = request.getParameter("color");	
		String message = "";
		boolean currentFlag= true;
		
		//this is pre form validation in server side.
		
		List<ValidationUtil> vus = new ArrayList<ValidationUtil>();
		ValidationUtil vu1= new ValidationUtil().stringVal("Friend Name", name);
		ValidationUtil vu2= new ValidationUtil().stringVal("Friend Email Address", email);
		ValidationUtil vu3= new ValidationUtil().stringVal("Favorite Color", color);
		ValidationUtil vu4= new ValidationUtil().intVal("Friend Age", age);
		vus.add(vu1);
		vus.add(vu2);
		vus.add(vu3);
		vus.add(vu4);
		for (ValidationUtil vu: vus) {
			if(!vu.isFlag()) {
				message=message.concat(vu.getMessage());
				currentFlag=false;
			}
		}
		
		// if currentFlag is true, that means all the parameters have been validated.
		if (currentFlag) {
			Friend friend = new Friend(name,email,vu4.getNumber(),color);
			int recordCount =new FriendDaoImpl().addFriend(friend);
			if (recordCount>0) {
				message="you have success to add "+String.valueOf(recordCount)+" record(s) into table FRIENDS";
			}else {
				message="you have failed to add a new record into table FRIENDS";
			}
			
		}
		
		
		List<Friend> friends = new FriendDaoImpl().findAll();
		
		request.getSession().removeAttribute("message");
		request.getSession().setAttribute("message", message);	
		request.getSession().removeAttribute("friends");
		request.getSession().setAttribute("friends", friends);	
		RequestDispatcher rd = request.getRequestDispatcher("read.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
