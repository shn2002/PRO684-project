package ca.senecacollege.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ca.senecacollege.dao.impl.FriendDaoImpl;
import ca.senecacollege.model.Friend;

/**
 * Servlet implementation class Delete
 */
//@WebServlet("/Delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Delete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String message = null;
		if (id != null&&!id.isEmpty()){
			try {
				int q = Integer. parseInt(id);
				int recordCount =new FriendDaoImpl().deleteFriend(q);
				if (recordCount>0 ) {
					message="you have success to delete "+String.valueOf(recordCount)+" record(s) from database";
				}else if (recordCount==-1) {
					message="the friend you want delete doesn't exist";
				}else {
					message="you have failed to delete a record from database";
				}		
				
			} catch (NumberFormatException e) {
				message="The friend id is not an int";
				e.printStackTrace();
			}
			
		}else {
			message="The friend id should not be blank";
		}
		
		List<Friend> friends = new FriendDaoImpl().findAll();
		request.getSession().removeAttribute("message");
		request.getSession().setAttribute("message", message);	
		request.getSession().removeAttribute("friends");
		request.getSession().setAttribute("friends", friends);	
		RequestDispatcher rd = request.getRequestDispatcher("read.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
