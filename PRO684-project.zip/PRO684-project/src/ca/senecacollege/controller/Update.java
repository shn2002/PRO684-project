package ca.senecacollege.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ca.senecacollege.dao.impl.FriendDaoImpl;
import ca.senecacollege.model.Friend;
import ca.senecacollege.util.ValidationUtil;

/**
 * Servlet implementation class Update
 */
//@WebServlet("/Update")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Update() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String age = request.getParameter("age");	
		String email = request.getParameter("email");	
		String color = request.getParameter("color");	
		String message = null;
		boolean currentFlag= true;
		
		//this is pre form validation in server side.
		
		List<ValidationUtil> vus = new ArrayList<ValidationUtil>();
		ValidationUtil vu1= new ValidationUtil().stringVal("Friend Name", name);
		ValidationUtil vu2= new ValidationUtil().stringVal("Friend Email Address", email);
		ValidationUtil vu3= new ValidationUtil().stringVal("Favorite Color", color);
		ValidationUtil vu4= new ValidationUtil().intVal("Friend Age", age);
		ValidationUtil vu5= new ValidationUtil().intVal("Friend ID", id);
		vus.add(vu1);
		vus.add(vu2);
		vus.add(vu3);
		vus.add(vu4);
		for (ValidationUtil vu: vus) {
			if(!vu.isFlag()) {
				message=message.concat(vu.getMessage());
				currentFlag=false;
			}
		}
		
		//Product product =new ProductDaoImpl().findById(pid);
		if (currentFlag) {
			Friend friend =new FriendDaoImpl().findById(vu5.getNumber());
			if (friend!=null) {
				friend.setFriendName(name);
				friend.setAge(vu4.getNumber());
				friend.setEmailAddress(email);
				friend.setFavoriteColor(color);
				friend.setFriendID(vu5.getNumber());
				int recordCount=new FriendDaoImpl().updateFriend(friend);
				if (recordCount>0) {
					message="you have success to update "+String.valueOf(recordCount)+" record(s) into table FRIENDS";
				}else {
					message="you have failed to update "+String.valueOf(recordCount)+" record(s) into table FRIENDS";
				}
			}else {
					message="The friend id doesn't exsit";
			}				
			
		}
		List<Friend> friends = new FriendDaoImpl().findAll();
		
		request.getSession().removeAttribute("message");
		request.getSession().setAttribute("message", message);	
		request.getSession().removeAttribute("friends");
		request.getSession().setAttribute("friends", friends);	
		RequestDispatcher rd = request.getRequestDispatcher("read.jsp");
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
