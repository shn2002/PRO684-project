package ca.senecacollege.service;

import java.util.List;

import ca.senecacollege.model.Message;
import ca.senecacollege.model.Product;

public interface ProductServiceI  {
	Product findById(int id ); 
	List<Product> findAll();
	Message delete(int id);
	Message update(Product product);
}
