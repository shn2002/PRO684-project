package ca.senecacollege.service;

import java.util.List;

import ca.senecacollege.model.Message;
import ca.senecacollege.model.Product;
import ca.senecacollege.model.User;

public interface ProductServiceI  {
	Product findById(int id); 
	List<Product> findAll();
	Message delete(int id,User user);
	Message update(Product product,User user);
	Message add(Product product, User user);
}
