package ca.senecacollege.service;

import java.util.List;

import ca.senecacollege.model.Claim;
import ca.senecacollege.model.Message;
import ca.senecacollege.model.User;

public interface ClaimServiceI  {
	Message add(Claim claim,User user);
	Claim findById(int id, User u);
	List<Claim> findAll(User u);
	List<Claim> findByPlanId(int id, User u);
	List<Claim> findAllOrderbyPlan(User u);
	List<Claim> findAllOrderbyDate(User u);
}
