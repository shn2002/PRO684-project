package ca.senecacollege.service;

import java.util.List;

import ca.senecacollege.model.Message;
import ca.senecacollege.model.Plan;
import ca.senecacollege.model.User;

public interface PlanServiceI  {
	Message add(Plan plan,User u);
	Plan findById(int id,User u);
	List<Plan> findAll(User u);
	Message delete(int id,User u);
	Message update(Plan t,User u);	
	
}
