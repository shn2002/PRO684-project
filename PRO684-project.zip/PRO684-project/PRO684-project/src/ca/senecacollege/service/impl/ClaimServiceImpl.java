package ca.senecacollege.service.impl;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import ca.senecacollege.dao.ClaimDaoI;
import ca.senecacollege.dao.impl.ClaimDaoImpl;
import ca.senecacollege.model.Claim;
import ca.senecacollege.model.Message;
import ca.senecacollege.model.User;
import ca.senecacollege.service.ClaimServiceI;

public class ClaimServiceImpl implements ClaimServiceI {
	ClaimDaoI dao = new ClaimDaoImpl();
	Message message = new Message();
	@Override
	public Message add(Claim claim,User user) {
		int size = claim.getPlan().getClaims().size();
		Date purchaseDate = claim.getPlan().getPurchasedate();
		Date nowDate = Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
		int days = (int) ((nowDate.getTime() - purchaseDate.getTime()) / (1000*3600*24));
		int year=days/365;
		
		if (size>=3) {
			message.setFlag(false);
			message.setInfo("Claim should be for a maximum of 3 times");
		}else if (year>=5){
			message.setFlag(false);
			message.setInfo("Claim should be within the five years of the protection plan");	
		}else {
			//check user authority
			if(claim.getPlan().getUser().getId()!=user.getId()&&user.getIsadmin().ordinal()!=1) {
				message.setFlag(false);
				message.setInfo("You can't add the claim under the protection not belonging to you");
			}else {
				int count=dao.add(claim);
				if (count>0) {
					message.setFlag(true);
					message.setInfo("You add the claim successfully");
				}else {
					message.setFlag(false);
					message.setInfo("You failed to add a claim to plan");
				}
			}
											
		}
		
		return message;
	}

	@Override
	public Claim findById(int id, User u) {
		return dao.findById(id, u);
	}

	@Override
	public List<Claim> findAll(User u) {
		return dao.findAll(u);
	}


	@Override
	public List<Claim> findAllOrderbyPlan(User u) {
		return dao.findAll(u, "planid");
	}

	@Override
	public List<Claim> findAllOrderbyDate(User u) {
		return dao.findAll(u, "claimdate");
	}

	@Override
	public List<Claim> findByPlanId(int id, User u) {
		return dao.findByPlanId(id, u);
	}

	@Override
	public Message update(Claim claim, User user) {
		if(claim.getPlan().getUser().getId()!=user.getId()&&user.getIsadmin().ordinal()!=1) {
			message.setFlag(false);
			message.setInfo("You can't update the claim for other users");
		}else {
			int count=dao.update(claim, user);
			if (count>0) {
				message.setFlag(true);
				message.setInfo("You updated the claim successfully");
			}else {
				message.setFlag(false);
				message.setInfo("You failed to update a claim");
			
		}
		}
		return message;
	}

	@Override
	public Message delete(int id, User user) {
		if(user.getIsadmin().ordinal()!=1) {
			message.setFlag(false);
			message.setInfo("You can't delete a claim as a customer");
		}else {
			int count=dao.delete(id, user);
			if (count>0) {
				message.setFlag(true);
				message.setInfo("You deleted the claim successfully");
			}else {
				message.setFlag(false);
				message.setInfo("You failed to delete a claim");
			
		}
		}
		return message;
	}

}
