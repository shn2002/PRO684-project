package ca.senecacollege.service.impl;

import java.util.List;

import ca.senecacollege.dao.ProductDaoI;
import ca.senecacollege.dao.impl.ProductDaoImpl;
import ca.senecacollege.model.Message;
import ca.senecacollege.model.Product;
import ca.senecacollege.service.ProductServiceI;

public class ProductServiceImpl implements ProductServiceI{
	ProductDaoI dao = new ProductDaoImpl();
	Message message = new Message();
	@Override
	public Product findById(int id) {
		
		return null;
	}
	@Override
	public List<Product> findAll() {
		
		return dao.findAll();
	}
	@Override
	public Message delete(int id) {
		int count =dao.delete(id);
		if(count>0) {
			message.setFlag(true);
			message.setInfo("You delete product successfully");
		}else if (count==-1) {
			message.setFlag(false);
			message.setInfo("Product you delete can't find");	
			}
			else {
				message.setFlag(false);
				message.setInfo("failed to delete product");	
			}
		return message;
	}
	@Override
	public Message update(Product product) {
		int count =dao.update(product);
		if(count>0) {
			message.setFlag(true);
			message.setInfo("You update product successfully");
		}else if (count==-1) {
			message.setFlag(false);
			message.setInfo("Product you update can't find");	
			}
			else {
				message.setFlag(false);
				message.setInfo("failed to update product");	
			}
		return message;
	}

	


	
}
