package ca.senecacollege.service.impl;

import java.util.List;

import ca.senecacollege.dao.ProductDaoI;
import ca.senecacollege.dao.impl.ProductDaoImpl;
import ca.senecacollege.model.Message;
import ca.senecacollege.model.Product;
import ca.senecacollege.model.User;
import ca.senecacollege.service.ProductServiceI;

public class ProductServiceImpl implements ProductServiceI{
	ProductDaoI dao = new ProductDaoImpl();
	Message message = new Message();
	@Override
	public Product findById(int id) {
		
		return dao.findById(id);
	}
	@Override
	public List<Product> findAll() {
		
		return dao.findAll();
	}
	@Override
	public Message delete(int id, User user) {
		if (user.getIsadmin().ordinal()==0) {
			message.setFlag(false);
			message.setInfo("You are not an admin and can't delete product");	
		}else 
		{
		int count =dao.delete(id);
		if(count>0) {
			message.setFlag(true);
			message.setInfo("You delete product successfully");
		}else if (count==-1) {
			message.setFlag(false);
			message.setInfo("Product you delete can't find");	
			}
			else {
				message.setFlag(false);
				message.setInfo("failed to delete product");	
			}
	}
		return message;
	}
	
	@Override
	public Message update(Product product, User user) {
		if (user.getIsadmin().ordinal()==0) {
			message.setFlag(false);
			message.setInfo("You are not an admin and can't update other product");	
		}else 
		{
		int count =dao.update(product);
		if(count>0) {
			message.setFlag(true);
			message.setInfo("You update product successfully");
		}else if (count==-1) {
			message.setFlag(false);
			message.setInfo("Product you update can't find");	
			}
			else {
				message.setFlag(false);
				message.setInfo("failed to update product");	
			}
		}
		return message;
	}
	@Override
	public Message add(Product product, User user) {
		if (user.getIsadmin().ordinal()==0) {
			message.setFlag(false);
			message.setInfo("You are not an admin and can't add product");	
		}else 
		{
			int count=dao.add(product);
			if (count>0) {
				message.setFlag(true);
				message.setInfo("You added product successfully");
				}else {
					message.setFlag(false);
					message.setInfo("The operation is failed because internal error");	
				}
		}
			
		return message;
	}


	


	
}
