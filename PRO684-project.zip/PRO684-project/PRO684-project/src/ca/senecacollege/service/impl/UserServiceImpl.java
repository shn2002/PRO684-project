package ca.senecacollege.service.impl;

import java.util.ArrayList;
import java.util.List;

import ca.senecacollege.dao.UserDaoI;
import ca.senecacollege.dao.impl.UserDaoImpl;
import ca.senecacollege.model.Message;
import ca.senecacollege.model.Plan;
import ca.senecacollege.model.User;
import ca.senecacollege.service.PlanServiceI;
import ca.senecacollege.service.UserServiceI;

public class UserServiceImpl implements UserServiceI{
	UserDaoI dao = new UserDaoImpl();
	Message message = new Message();
	
	public Message signUp(User u) {
		if (dao.add(u)>0) {
			message.setFlag(true);
			message.setInfo("You signed up successfully");
		}else 
		{
			message.setFlag(false);
			message.setInfo("You failed to sign up");
		}
		return message;
	}

	public Message signIn(User u) {
		User user = dao.findByName(u.getUsername());
		if (user.getUsername() != null) {
			if (user.getPassword().equals(u.getPassword())) {
				message.setFlag(true);
				message.setInfo("You login in successfully");
			}else {
				message.setFlag(false);
				message.setInfo("Sorry, password doen't match");
			}
		}else {
			message.setFlag(false);
			message.setInfo("Sorry, the user doesn't exsit");
		}
		return message;
	}

	public Message deleteUser(int uid,User user) {
		if (user.getIsadmin().ordinal()!=1) {
			message.setFlag(true);
			message.setInfo("You can't delete user account as a customer");
		}
		else 
		{
			int count =dao.delete(uid, user);
			if (count>0) {
				message.setFlag(true);
				message.setInfo("You delete user successfully");
			}else if (count==-1) {
				message.setFlag(false);
				message.setInfo("User you delete can't find");
		}
		}
		return message;
	}

	public Message updateUser(User t,User u) {
		int count =dao.update(t, u);
		if (count>0) {
			message.setFlag(true);
			message.setInfo("You updated user successfully");
		}else {
			if(u.getIsadmin().ordinal()==0) {
			message.setFlag(false);
			message.setInfo("You are not an admin and can't update other account");	
			}
			else {
				message.setFlag(false);
				message.setInfo("User you update can't find");	
			}
		}
		return message;
	}
	public Message addUser(User t,User u) {
		if(u.getIsadmin().ordinal()!=1) {
			message.setFlag(false);
			message.setInfo("You are not an admin and can't add account");	
		}else {
			int count=dao.add(t);
			if (count>0) {
				message.setFlag(true);
				message.setInfo("You added user successfully");
				}else {
					message.setFlag(false);
					message.setInfo("The operation is failed because internal error");	
				}
		}
			
		return message;
	}

	public User findByName(String name) {
		return dao.findByName(name);
	}
	
	public User findById(int id, User u) {
		User user = dao.findById(id, u);
		PlanServiceI planservice = new PlanServiceImpl();
		List<Plan> plans = planservice.findByUserId(user, u);
		user.setPlans(plans);
		return user;
	}
	
	public List<User> findAll(User u){
		List<User> users= dao.findAll(u);
		for(User user:users) {
			List<Plan> plans = new ArrayList<Plan>();
			plans=new PlanServiceImpl().findByUserId(user, u);
			user.setPlans(plans);
		}
		return users;
	}
   
	
}
