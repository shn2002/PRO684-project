package ca.senecacollege.service.impl;

import ca.senecacollege.dao.UserDaoI;
import ca.senecacollege.dao.impl.UserDaoImpl;
import ca.senecacollege.model.Message;
import ca.senecacollege.model.User;
import ca.senecacollege.service.UserServiceI;

public class UserServiceImpl implements UserServiceI{
	UserDaoI dao = new UserDaoImpl();
	Message message = new Message();
	
	public Message signUp(User u) {
		if (dao.add(u)>0) {
			message.setFlag(true);
			message.setInfo("You signed up successfully");
		}else 
		{
			message.setFlag(false);
			message.setInfo("You failed to sign up");
		}
		return message;
	}

	public Message signIn(User u) {
		User user = dao.findByName(u.getUsername());
		if (user != null) {
			if (user.getPassword()==u.getPassword()) {
				message.setFlag(true);
				message.setInfo("You login in successfully");
			}else {
				message.setFlag(false);
				message.setInfo("Sorry, password doen't match");
			}
		}else {
			message.setFlag(false);
			message.setInfo("Sorry, the user doesn't exsit");
		}
		return message;
	}

	public Message deleteUser(int uid,User user) {
		if (user.getIsadmin().ordinal()!=1) {
			message.setFlag(true);
			message.setInfo("You can't delete user account as a customer");
		}
		else 
		{
			int count =dao.delete(uid, user);
			if (count>0) {
				message.setFlag(true);
				message.setInfo("You delete user successfully");
			}else if (count==-1) {
				message.setFlag(false);
				message.setInfo("User you delete can't find");
		}
		}
		return message;
	}

	public Message updateUser(User t,User u) {
		int count =dao.update(t, u);
		if (count>0) {
			message.setFlag(true);
			message.setInfo("You update user successfully");
		}else {
			if(u.getIsadmin().ordinal()==0) {
			message.setFlag(false);
			message.setInfo("You are not an admin and can't update other account");	
			}
			else {
				message.setFlag(false);
				message.setInfo("User you update can't find");	
			}
		}
		return message;
	}

	
}
