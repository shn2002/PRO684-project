package ca.senecacollege.service.impl;

import java.util.List;

import ca.senecacollege.dao.PlanDaoI;
import ca.senecacollege.dao.impl.PlanDaoImpl;
import ca.senecacollege.model.Message;
import ca.senecacollege.model.Plan;
import ca.senecacollege.model.User;
import ca.senecacollege.service.PlanServiceI;

public class PlanServiceImpl implements PlanServiceI {
	PlanDaoI dao = new PlanDaoImpl();
	Message message = new Message();
	@Override
	public Message add(Plan plan, User user) {
		if(plan.getUser().getId()!=user.getId()&&user.getIsadmin().ordinal()!=1) {
			message.setFlag(false);
			message.setInfo("You can't add the plan for other users");
		}else {
			int count=dao.add(plan);
			if (count>0) {
				message.setFlag(true);
				message.setInfo("You add the plan successfully");
			}else {
				message.setFlag(false);
				message.setInfo("You failed to add a plan");
		}
		}
		return message;
	}

	@Override
	public Plan findById(int id, User u) {
		return dao.findById(id, u);
	}

	@Override
	public List<Plan> findAll(User u) {
		// TODO Auto-generated method stub
		return dao.findAll(u);
	}

	@Override
	public Message delete(int id, User u) {
		if(u.getIsadmin().ordinal()!=1) {
			message.setFlag(false);
			message.setInfo("You can't delete a plan as a customer");
		}else {
			int count=dao.delete(id, u);
			if (count>0) {
				message.setFlag(true);
				message.setInfo("You deleted the plan successfully");
			}else {
				message.setFlag(false);
				message.setInfo("You failed to delete a plan");
			
		}
		}
		return message;
	}

	@Override
	public Message update(Plan plan, User user) {
		if(plan.getUser().getId()!=user.getId()&&user.getIsadmin().ordinal()!=1) {
			message.setFlag(false);
			message.setInfo("You can't update the plan for other users");
		}else {
			int count=dao.update(plan, user);
			if (count>0) {
				message.setFlag(true);
				message.setInfo("You updated the plan successfully");
			}else {
				message.setFlag(false);
				message.setInfo("You failed to update a plan");
			
		}
		}
		return message;
	}

}