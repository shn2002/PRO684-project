package ca.senecacollege.service.impl;

import java.util.ArrayList;
import java.util.List;

import ca.senecacollege.dao.PlanDaoI;
import ca.senecacollege.dao.impl.PlanDaoImpl;
import ca.senecacollege.model.Claim;
import ca.senecacollege.model.Message;
import ca.senecacollege.model.Plan;
import ca.senecacollege.model.User;
import ca.senecacollege.service.PlanServiceI;

public class PlanServiceImpl implements PlanServiceI {
	PlanDaoI dao = new PlanDaoImpl();
	Message message = new Message();
	@Override
	public Message add(Plan plan, User user) {
		if(plan.getUser().getId()!=user.getId()&&user.getIsadmin().ordinal()!=1) {
			message.setFlag(false);
			message.setInfo("You can't add the plan for other users");
		}else {
			int count=dao.add(plan);
			if (count>0) {
				message.setFlag(true);
				message.setInfo("You add the plan successfully");
			}else {
				message.setFlag(false);
				message.setInfo("You failed to add a plan");
		}
		}
		return message;
	}

	@Override
	public Plan findById(int id, User u) {
		Plan plan =dao.findById(id, u);
		List<Claim> claims = new ArrayList<Claim>();
		claims=new ClaimServiceImpl().findByPlanId(plan.getId(), u);
		plan.setClaims(claims);
		return plan;
	}

	@Override
	public List<Plan> findAll(User u) {
		List<Plan> plans= dao.findAll(u);
		for(Plan plan:plans) {
			List<Claim> claims = new ArrayList<Claim>();
			claims=new ClaimServiceImpl().findByPlanId(plan.getId(), u);
			plan.setClaims(claims);
		}
		return plans;
	}

	@Override
	public Message delete(int id, User u) {
		if(u.getIsadmin().ordinal()!=1) {
			message.setFlag(false);
			message.setInfo("You can't delete a plan as a customer");
		}else {
			int count=dao.delete(id, u);
			if (count>0) {
				message.setFlag(true);
				message.setInfo("You deleted the plan successfully");
			}else {
				message.setFlag(false);
				message.setInfo("You failed to delete a plan");
			
		}
		}
		return message;
	}

	@Override
	public Message update(Plan plan, User user) {
		if(plan.getUser().getId()!=user.getId()&&user.getIsadmin().ordinal()!=1) {
			message.setFlag(false);
			message.setInfo("You can't update the plan for other users");
		}else {
			int count=dao.update(plan, user);
			if (count>0) {
				message.setFlag(true);
				message.setInfo("You updated the plan successfully");
			}else {
				message.setFlag(false);
				message.setInfo("You failed to update a plan");
			
		}
		}
		return message;
	}

	@Override
	public List<Plan> findByUserId(User t, User u) {
		List<Plan> plans= dao.findByUserId(t, u);
		for(Plan plan:plans) {
			List<Claim> claims = new ArrayList<Claim>();
			claims=new ClaimServiceImpl().findByPlanId(plan.getId(), u);
			plan.setClaims(claims);
		}
		return plans;
		
	}

	@Override
	public List<Plan> search(String keyword,User u) {
		List<Plan> plans= dao.findAll(u);
		List<Plan> newplans= new ArrayList<Plan>();
		for (Plan plan : plans) {
			if (plan.getProduct().getProductname().contains(keyword)) {
				newplans.add(plan);
				
			}
			
		}
		return newplans;
	}

}