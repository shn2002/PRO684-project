package ca.senecacollege.service;

import java.util.List;

import ca.senecacollege.model.Message;
import ca.senecacollege.model.User;

public interface UserServiceI  {
	Message signUp(User u); 
	Message signIn(User u); 
	Message deleteUser(int uid,User u);
    Message updateUser(User t,User u);
    User findByName(String name);
    User findById(int id, User u);
    List<User> findAll(User u);
    Message addUser(User t,User u);
    List<User> search(String keyword,User u);
}
