package ca.senecacollege.util;

import ca.senecacollege.model.User;

public class SQLUtil {
	
	public String appendUserID (String sql,User u) {
		String newSql= sql;
		if (u.getIsadmin().name()=="CUSTOMER") {
			if (newSql.contains("plan")) {
				newSql = newSql+" and userid= "+String.valueOf(u.getId());
			}else if(newSql.contains("claim")){
				newSql = newSql+" and planid in (select planid from plan where userid= "+String.valueOf(u.getId())+" )";
			}else {
				newSql = newSql+" and id= "+String.valueOf(u.getId());
				
			}
					
					
					
			
		}
		return newSql;
	}

}
