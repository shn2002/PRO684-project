package ca.senecacollege.util;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ca.senecacollege.model.Message;
import ca.senecacollege.model.User;

public class SessionUtil {
	public boolean loginCheck(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws ServletException, IOException {
		User user = (User)session.getAttribute("user");
		if (user==null) {	
			Message message = new Message(false,"You are not logining in");
			session.setAttribute("message", message);
			RequestDispatcher rd= request.getRequestDispatcher("SignIn.jsp");
			rd.forward(request, response);
			return false;
		}
		return true;
	}
}
