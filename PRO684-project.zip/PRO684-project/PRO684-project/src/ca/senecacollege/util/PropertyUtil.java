package ca.senecacollege.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyUtil {

	private  String driver ; 
	private  String url; 
	private  String username; 
	private  String password;
	
	
	public PropertyUtil() {
		try {
		Properties properties = new Properties();
		//InputStream is = PropertyUtil.class.getResourceAsStream("dbConn.properties");
		InputStream is =getClass().getClassLoader().getResourceAsStream("dbConn.properties");
	    properties.load(is);
		driver = properties.getProperty("driver");
		url = properties.getProperty("url");
		username = properties.getProperty("username");
		password = properties.getProperty("password");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public String getDriver() {
		return driver;
	}


	public String getUrl() {
		return url;
	}


	public String getUsername() {
		return username;
	}


	public String getPassword() {
		return password;
	}
	}
		


