package ca.senecacollege.util;

import java.util.ArrayList;

import ca.senecacollege.model.Node;

public class TreeUtil {
	
	public Node createAdminTreeView() {
		Node root = new Node(1,"Root","#",new ArrayList<Node>());
		Node userNode= new Node(2,"User Account Management","#",new ArrayList<Node>());
		Node productNode= new Node(3,"Product Information Management","#",new ArrayList<Node>());
		Node planNode= new Node(4,"Plan Information Management","#",new ArrayList<Node>());
		Node claimNode= new Node(5,"Claim Information Management","#",new ArrayList<Node>());
		
		
		Node userAdd = new Node(6,"Add User","AddUser",null);
		Node userShow = new Node(7,"Show Users","ShowUsers",null);
		userNode.getChildnodes().add(userAdd);
		userNode.getChildnodes().add(userShow);
		
		Node productAdd = new Node(8,"Add Product","AddProduct",null);
		Node productShow = new Node(9,"Show Products","ShowProducts",null);
		productNode.getChildnodes().add(productAdd);
		productNode.getChildnodes().add(productShow);
		
		Node planAdd = new Node(10,"Add Plan","AddPlan",null);
		Node planShow = new Node(11,"Show plans","ShowPlan",null);
		productNode.getChildnodes().add(planAdd);
		productNode.getChildnodes().add(planShow);
		
		Node claimAdd = new Node(12,"Add Claim","AddClaim",null);
		Node claimShow = new Node(13,"Show Claims","ShowPlans",null);
		claimNode.getChildnodes().add(claimAdd);
		claimNode.getChildnodes().add(claimShow);
		
	
		root.getChildnodes().add(userNode);
		root.getChildnodes().add(productNode);
		root.getChildnodes().add(planNode);
		root.getChildnodes().add(claimNode);
		
		return root;
	}
	
	public Node createCustomerTreeView() {
		Node root = new Node(1,"Root","#",new ArrayList<Node>());
		Node userNode= new Node(2,"User Account Management","#",new ArrayList<Node>());
		Node productNode= new Node(3,"Product Information Management","#",new ArrayList<Node>());
		Node planNode= new Node(4,"Plan Information Management","#",new ArrayList<Node>());
		Node claimNode= new Node(5,"Claim Information Management","#",new ArrayList<Node>());
		
		
		Node userShow = new Node(7,"Show Users","ShowUsers",null);
		userNode.getChildnodes().add(userShow);
		
		Node productShow = new Node(9,"Show Products","ShowProducts",null);
		productNode.getChildnodes().add(productShow);
		
		Node planAdd = new Node(10,"Add Plan","AddPlan",null);
		Node planShow = new Node(11,"Show plans","ShowPlan",null);
		productNode.getChildnodes().add(planAdd);
		productNode.getChildnodes().add(planShow);
		
		Node claimAdd = new Node(12,"Add Claim","AddClaim",null);
		Node claimShow = new Node(13,"Show Claims","ShowPlans",null);
		claimNode.getChildnodes().add(claimAdd);
		claimNode.getChildnodes().add(claimShow);
		
	
		root.getChildnodes().add(userNode);
		root.getChildnodes().add(productNode);
		root.getChildnodes().add(planNode);
		root.getChildnodes().add(claimNode);
		
		return root;
	}

}
