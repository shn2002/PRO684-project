package ca.senecacollege.dao;

import java.util.List;

import ca.senecacollege.model.User;


public interface BaseDaoI<T> {
	T findById(int id,User u); 
	List<T> findAll(User u); 
	int delete(int id,User u);
	int update(T t,User u);
	int add(T t);
	
}
