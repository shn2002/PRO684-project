package ca.senecacollege.dao;

import java.util.List;

import ca.senecacollege.model.Product;

public interface ProductDaoI {
	int add(Product product);
	Product findById(int id);
	List<Product> findAll();
	int delete(int id);
	int update(Product product);
	
}
