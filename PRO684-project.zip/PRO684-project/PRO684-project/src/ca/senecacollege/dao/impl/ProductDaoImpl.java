package ca.senecacollege.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ca.senecacollege.dao.ProductDaoI;
import ca.senecacollege.model.Product;
import ca.senecacollege.util.DBUtil;

public class ProductDaoImpl implements ProductDaoI{

	DBUtil dbUtil = new DBUtil();
	Product product= new Product();
	List<Product> products= new ArrayList<Product>();
	
	public int add(Product product) {
		String sql = "insert into product(productname,serialnumber) values(?,?)";
		List<Object> params = new ArrayList<Object>();
		params.add(product.getProductname());
		params.add(product.getSerialnumber());
		return dbUtil.executeOperate(sql,params);
	}

	public Product findById(int id) {
		String sql ="select * from product where id=?";
		List<Object> params = new ArrayList<Object>();
		params.add(id);
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				product.setId(rs.getInt("id"));
				product.setProductname(rs.getString("productname"));
				product.setSerialnumber(rs.getString("serialnumber"));	
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return product;
	}

	public List<Product> findAll() {
		String sql ="select * from product";
		List<Object> params = new ArrayList<Object>();
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				Product product = new Product();
				product.setId(rs.getInt("id"));
				product.setProductname(rs.getString("productname"));
				product.setSerialnumber(rs.getString("serialnumber"));
				products.add(product);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return products;

	}

	public int delete(int id) {
		Product product = findById(id);
		if (product.getProductname() ==null) {
			return -1;
		}else {
			
			String sql = "delete from product where id=?";
			List<Object> params = new ArrayList<Object>();
			params.add(product.getId());
			return dbUtil.executeOperate(sql,params);	
		}
	}

	public int update(Product product) {
		String sql = "update FRIENDS set productname=?, serialnumber=? where id=?";
		List<Object> params = new ArrayList<Object>();			
		params.add(product.getProductname());
		params.add(product.getSerialnumber());
		return dbUtil.executeOperate(sql,params);	
	}








}
