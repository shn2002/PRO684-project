package ca.senecacollege.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import ca.senecacollege.dao.ClaimDaoI;
import ca.senecacollege.model.Claim;
import ca.senecacollege.model.Plan;
import ca.senecacollege.model.StatusType;
import ca.senecacollege.model.User;
import ca.senecacollege.util.DBUtil;
import ca.senecacollege.util.SQLUtil;

public class ClaimDaoImpl implements ClaimDaoI{

	DBUtil dbUtil = new DBUtil();
	Claim claim= new Claim();
	List<Claim> claims= new LinkedList<Claim>();
	
	@Override
	public int add(Claim claim) {
		String sql = "insert into claim(detaildesc,incident,cstatus,claimdate,planid) values(?,?,?,?,?)";
		List<Object> params = new ArrayList<Object>();
		params.add(claim.getDetaildesc());
		params.add(claim.getIncident());
		params.add(claim.getCstatus().ordinal());
		params.add(claim.getPlan().getId());
		params.add(claim.getClaimdate());
		return dbUtil.executeOperate(sql,params);
		
	}
	
	@Override
	public Claim findById(int id, User u) {
		String sql=new SQLUtil().appendUserID("select * from claim where id=?",u);
		List<Object> params = new ArrayList<Object>();
		params.add(id);
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				claim.setId(rs.getInt("id"));
				claim.setDetaildesc(rs.getString("detaildesc"));
				Plan plan = new PlanDaoImpl().findById(rs.getInt("id"),u);
				claim.setPlan(plan);
				StatusType st=StatusType.valueOf(rs.getString("cstatus"));
				claim.setCstatus(st);
				claim.setClaimdate(rs.getDate("claimdate"));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return claim;
	}

	@Override
	public List<Claim> findAll(User u) {
		String sql=new SQLUtil().appendUserID("select * from claim where 1=1 ",u);
		List<Object> params = new ArrayList<Object>();
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				Claim claim = new Claim();
				claim.setId(rs.getInt("id"));
				Plan plan = new PlanDaoImpl().findById(rs.getInt("id"),u);
				claim.setPlan(plan);
				StatusType st=StatusType.valueOf(rs.getString("cstatus"));
				claim.setCstatus(st);
				claim.setClaimdate(rs.getDate("claimdate"));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return claims;
	}
	@Override
	public List<Claim> findAll(User u, String orderBy) {
		String sql=new SQLUtil().appendUserID("select * from claim where 1=1 ",u)+" order by";
		List<Object> params = new ArrayList<Object>();
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				Claim claim = new Claim();
				claim.setId(rs.getInt("id"));
				Plan plan = new PlanDaoImpl().findById(rs.getInt("id"),u);
				claim.setPlan(plan);
				StatusType st=StatusType.valueOf(rs.getString("cstatus"));
				claim.setCstatus(st);
				claim.setClaimdate(rs.getDate("claimdate"));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return claims;
	}
	
	
	
	@Override
	public int delete(int id, User u) {
		Claim claim = findById(id,u);
		if (claim.getDetaildesc() ==null) {
			return -1;
		}else {
			String sql=new SQLUtil().appendUserID("delete from claim where id=?",u);
			List<Object> params = new ArrayList<Object>();
			params.add(claim.getId());
			return dbUtil.executeOperate(sql,params);	
		}
	}

	@Override
	public int update(Claim t, User u) {
		String sql=new SQLUtil().appendUserID( "update claim(detaildesc,incident,cstatus,claimdate,planid) set detaildesc=?, incident=?, cstatus=?, claimdate=?, planid=? where id=?",u);
		List<Object> params = new ArrayList<Object>();			
		params.add(claim.getDetaildesc());
		params.add(claim.getIncident());
		params.add(claim.getCstatus().ordinal());
		params.add(claim.getClaimdate());
		params.add(claim.getPlan().getId());
		params.add(claim.getId());
		return dbUtil.executeOperate(sql,params);	
	}

	@Override
	public List<Claim> findByPlanId(int id, User u) {
		claims=findAll(u,"claimdate");
		for(Claim claim : claims) {
			if(claim.getPlan().getId()!=id) {
				claims.remove(claim);
			}
		}
		return claims;
	}


	



}
