package ca.senecacollege.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ca.senecacollege.dao.PlanDaoI;
import ca.senecacollege.model.Plan;
import ca.senecacollege.model.Product;
import ca.senecacollege.model.User;
import ca.senecacollege.util.DBUtil;
import ca.senecacollege.util.SQLUtil;

public class PlanDaoImpl implements PlanDaoI{

	DBUtil dbUtil = new DBUtil();
	Plan plan= new Plan();
	List<Plan> plans= new ArrayList<Plan>();
	
	public int add(Plan plan) {
		String sql = "insert into plan(purchasedate,userid,productid) values(?,?,?)";
		List<Object> params = new ArrayList<Object>();
		params.add(plan.getPurchasedate());
		params.add(plan.getUser().getId());
		params.add(plan.getProduct().getId());
		return dbUtil.executeOperate(sql,params);
	}

	public Plan findById(int id,User u) {
		String sql=new SQLUtil().appendUserID("select * from plan where id=?",u);
		List<Object> params = new ArrayList<Object>();
		params.add(id);
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				plan.setId(rs.getInt("id"));
				plan.setPurchasedate(rs.getDate("purchasedate"));
				User user = new UserDaoImpl().findById(rs.getInt("userid"),u);
				plan.setUser(user);
				Product product = new ProductDaoImpl().findById(rs.getInt("productid"));;
				plan.setProduct(product);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return plan;
	}

	public List<Plan> findByUserId(User t, User u) {
		String sql="select * from plan where userid=?";
		List<Object> params = new ArrayList<Object>();
		params.add(t.getId());
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				Plan plan = new Plan();
				plan.setId(rs.getInt("id"));
				plan.setPurchasedate(rs.getDate("purchasedate"));
				User user = new UserDaoImpl().findById(rs.getInt("userid"),u);
				plan.setUser(user);
				Product product = new ProductDaoImpl().findById(rs.getInt("productid"));
				plan.setProduct(product);
				plans.add(plan);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return plans;
	}
	
	public List<Plan> findAll(User u) {
		String sql=new SQLUtil().appendUserID("select * from plan where 1=1 ",u);
		List<Object> params = new ArrayList<Object>();
		ResultSet rs = dbUtil.executeQuery(sql, params);
		try {
			while(rs.next()){
				Plan plan = new Plan();
				plan.setId(rs.getInt("id"));
				plan.setPurchasedate(rs.getDate("purchasedate"));
				User user = new UserDaoImpl().findById(rs.getInt("userid"),u);
				plan.setUser(user);
				Product product = new ProductDaoImpl().findById(rs.getInt("productid"));
				plan.setProduct(product);
				plans.add(plan);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return plans;

	}

	public int delete(int id,User u) {
		Plan plan = findById(id,u);
		if (plan.getPurchasedate() ==null) {
			return -1;
		}else {
			String sql=new SQLUtil().appendUserID("delete from plan where id=? ",u);
			List<Object> params = new ArrayList<Object>();
			params.add(plan.getId());
			return dbUtil.executeOperate(sql,params);	
		}
	}

	public int update(Plan t,User u) {
		String sql=new SQLUtil().appendUserID("update plan set purchasedate=?, userid=?, productid=? where id=? ",u);
		List<Object> params = new ArrayList<Object>();			
		params.add(plan.getPurchasedate());
		params.add(plan.getUser().getId());
		params.add(plan.getProduct().getId());
		params.add(plan.getId());
		return dbUtil.executeOperate(sql,params);	
	}

	

	








}
