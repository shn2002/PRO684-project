package ca.senecacollege.dao;

import java.util.List;

import ca.senecacollege.model.Claim;
import ca.senecacollege.model.User;

public interface ClaimDaoI extends BaseDaoI<Claim> {
	List<Claim> findByPlanId(int id, User u);
	List<Claim> findAll(User u, String orderBy);

}
