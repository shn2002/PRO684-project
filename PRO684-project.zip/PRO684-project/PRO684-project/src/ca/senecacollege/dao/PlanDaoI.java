package ca.senecacollege.dao;

import java.util.List;

import ca.senecacollege.model.Plan;
import ca.senecacollege.model.User;


public interface PlanDaoI extends BaseDaoI<Plan>{
	List<Plan> findByUserId(User t, User u);
}
