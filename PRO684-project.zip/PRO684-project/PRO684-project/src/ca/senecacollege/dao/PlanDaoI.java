package ca.senecacollege.dao;

import ca.senecacollege.model.Plan;


public interface PlanDaoI extends BaseDaoI<Plan>{
	
}
