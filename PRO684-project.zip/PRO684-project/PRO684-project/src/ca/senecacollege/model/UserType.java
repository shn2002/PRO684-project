package ca.senecacollege.model;

public enum UserType {
	CUSTOMER,ADMIN
}
