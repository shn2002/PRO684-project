package ca.senecacollege.model;


public class Message {
	private boolean flag;
	private String info;
	
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public Message(boolean flag, String info) {
		super();
		this.flag = flag;
		this.info = info;
	}
	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}


}
