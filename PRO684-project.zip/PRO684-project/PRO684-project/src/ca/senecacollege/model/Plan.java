package ca.senecacollege.model;

import java.util.Date;
import java.util.List;

public class Plan {
	private int id;
	private Date purchasedate;
	private User user;
	private Product product;
	private List<Claim> claims;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(Date purchasedate) {
		this.purchasedate = purchasedate;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public List<Claim> getClaims() {
		return claims;
	}
	public void setClaims(List<Claim> claims) {
		this.claims = claims;
	}
	public Plan(int id, Date purchasedate, User user, Product product, List<Claim> claims) {
		super();
		this.id = id;
		this.purchasedate = purchasedate;
		this.user = user;
		this.product = product;
		this.claims = claims;
	}
	public Plan() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	
	
}
