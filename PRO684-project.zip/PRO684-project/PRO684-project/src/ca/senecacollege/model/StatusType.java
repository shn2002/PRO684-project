package ca.senecacollege.model;

public enum StatusType {
	APPROVED,REJECTED
}
