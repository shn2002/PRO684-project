package ca.senecacollege.model;

import java.util.Date;

public class Claim {
	private int id;
	private String detaildesc;
	private String incident;
	private Plan plan;
	private StatusType cstatus;
	private Date claimdate;


	public Claim(int id, String detaildesc, String incident, Plan plan, StatusType cstatus, Date claimdate) {
		super();
		this.id = id;
		this.detaildesc = detaildesc;
		this.incident = incident;
		this.plan = plan;
		this.cstatus = cstatus;
		this.claimdate = claimdate;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getDetaildesc() {
		return detaildesc;
	}


	public void setDetaildesc(String detaildesc) {
		this.detaildesc = detaildesc;
	}


	public String getIncident() {
		return incident;
	}


	public void setIncident(String incident) {
		this.incident = incident;
	}


	public Plan getPlan() {
		return plan;
	}


	public void setPlan(Plan plan) {
		this.plan = plan;
	}


	public StatusType getCstatus() {
		return cstatus;
	}


	public void setCstatus(StatusType cstatus) {
		this.cstatus = cstatus;
	}


	public Date getClaimdate() {
		return claimdate;
	}


	public void setClaimdate(Date claimdate) {
		this.claimdate = claimdate;
	}


	public Claim() {
		super();

	}

	
}
