package ca.senecacollege.model;

import java.util.List;

public class Node {
	private int id;
	private String name;
	private String href;
	private List<Node> childnodes;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHref() {
		return href;
	}
	public void setHref(String href) {
		this.href = href;
	}
	public List<Node> getChildnodes() {
		return childnodes;
	}
	public void setChildnodes(List<Node> childnodes) {
		this.childnodes = childnodes;
	}
	public Node(int id, String name, String href, List<Node> childnodes) {
		super();
		this.id = id;
		this.name = name;
		this.href = href;
		this.childnodes = childnodes;
	}
	public Node() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
