package ca.senecacollege.model;



public class Product {
	private int id;
	private String productname;
	private String serialnumber;
	
	public Product(int id, String productname, String serialnumber) {
		super();
		this.id = id;
		this.productname = productname;
		this.serialnumber = serialnumber;
	}
	
	public Product() {
		
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getSerialnumber() {
		return serialnumber;
	}
	public void setSerialnumber(String serialnumber) {
		this.serialnumber = serialnumber;
	}
	
	
	

}
