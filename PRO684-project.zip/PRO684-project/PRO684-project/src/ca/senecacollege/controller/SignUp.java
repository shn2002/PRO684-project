package ca.senecacollege.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ca.senecacollege.model.Message;
import ca.senecacollege.model.User;
import ca.senecacollege.service.UserServiceI;
import ca.senecacollege.service.impl.UserServiceImpl;
import ca.senecacollege.util.ValidationUtil;

/**
 * Servlet implementation class SignUp
 */
@WebServlet("/SignUp")
public class SignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String cellphone = request.getParameter("cellphone");
		String email = request.getParameter("email");
		String address = request.getParameter("email");
		Message message = new Message();
		message.setInfo("");
		
		//this is pre form validation in server side.
		
		List<ValidationUtil> vus = new ArrayList<ValidationUtil>();
		ValidationUtil vu1= new ValidationUtil().stringVal("User Name", username);
		ValidationUtil vu2= new ValidationUtil().stringVal("Password", password);
		ValidationUtil vu3= new ValidationUtil().stringVal("CellPhone", cellphone);
		ValidationUtil vu4= new ValidationUtil().stringVal("Email", email);
		ValidationUtil vu5= new ValidationUtil().stringVal("Address", address);

		vus.add(vu1);
		vus.add(vu2);
		vus.add(vu3);
		vus.add(vu4);
		vus.add(vu5);
		for (ValidationUtil vu: vus) {
			if(!vu.isFlag()) {
				message.setInfo(message.getInfo().concat(vu.getMessage()));
				message.setFlag(false);
			}
		}
		// if currentFlag is true, that means all the parameters have been validated.
				if (message.isFlag()) {
					User user = new User(username,password,cellphone,email,address);
					UserServiceI userservice = new UserServiceImpl();
					message=userservice.signUp(user);		
		}
				
				request.getSession().removeAttribute("message");
				request.getSession().setAttribute("message", message);	
				RequestDispatcher rd = request.getRequestDispatcher("SignIn.jsp");
				rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
