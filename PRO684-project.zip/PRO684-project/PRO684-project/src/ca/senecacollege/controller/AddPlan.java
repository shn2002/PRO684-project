package ca.senecacollege.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ca.senecacollege.model.Message;
import ca.senecacollege.model.Plan;
import ca.senecacollege.model.Product;
import ca.senecacollege.model.User;
import ca.senecacollege.service.PlanServiceI;
import ca.senecacollege.service.ProductServiceI;
import ca.senecacollege.service.UserServiceI;
import ca.senecacollege.service.impl.PlanServiceImpl;
import ca.senecacollege.service.impl.ProductServiceImpl;
import ca.senecacollege.service.impl.UserServiceImpl;
import ca.senecacollege.util.SessionUtil;
import ca.senecacollege.util.ValidationUtil;

/**
 * Servlet implementation class AddPlan
 */
@WebServlet("/AddPlan")
public class AddPlan extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddPlan() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		new SessionUtil().loginCheck(request, response, session);
		
		Message message = new Message(true,"");
		User user = (User)session.getAttribute("user");
		RequestDispatcher rd;
		
			String purchasedate = request.getParameter("purchasedate");
			String productid = request.getParameter("productid");
			String userid = request.getParameter("userid");
			List<ValidationUtil> vus = new ArrayList<ValidationUtil>();
			ValidationUtil vu2= new ValidationUtil().dateVal("Purchase Date", purchasedate);
			ValidationUtil vu3= new ValidationUtil().intVal("Product Name", productid);
			ValidationUtil vu4= new ValidationUtil().intVal("User Name", userid);
			vus.add(vu2);
			vus.add(vu3);
			vus.add(vu4);
			
			for (ValidationUtil vu: vus) {
				if(!vu.isFlag()) {
					message.setInfo(message.getInfo().concat(vu.getMessage()));
					message.setFlag(false);
					session.removeAttribute("message");
					session.setAttribute("message", message);
					rd = request.getRequestDispatcher("plans.jsp");
					rd.forward(request, response);
					return;
				}
			}
			
			if (message.isFlag()) {
				UserServiceI userservice = new UserServiceImpl();
				User puser = userservice.findById(vu4.getNumber(),user);
				ProductServiceI productservice= new ProductServiceImpl();
				Product product = productservice.findById(vu3.getNumber());
				PlanServiceI planservice = new PlanServiceImpl();
				Plan plan= new Plan(-1,vu2.getDate(),puser,product,null);
				message=planservice.add(plan, user);
				session.removeAttribute("message");
				session.setAttribute("message", message);
				session.removeAttribute("plans");
				List<User>users=userservice.findAll(user);
				session.setAttribute("users", users);
				rd = request.getRequestDispatcher("plans.jsp");
				rd.forward(request, response);
			}
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
