package ca.senecacollege.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ca.senecacollege.model.Message;
import ca.senecacollege.model.User;
import ca.senecacollege.service.UserServiceI;
import ca.senecacollege.service.impl.UserServiceImpl;
import ca.senecacollege.util.ValidationUtil;

/**
 * Servlet implementation class SignIn
 */
@WebServlet("/SignIn")
public class SignIn extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignIn() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		HttpSession session =request.getSession();
		RequestDispatcher rd;
		
		Message message = new Message(true,"");
		List<ValidationUtil> vus = new ArrayList<ValidationUtil>();
		ValidationUtil vu1= new ValidationUtil().stringVal("User Name", username);
		ValidationUtil vu2= new ValidationUtil().stringVal("Password", password);
		vus.add(vu1);
		vus.add(vu2);

		for (ValidationUtil vu: vus) {
			if(!vu.isFlag()) {
				message.setInfo(message.getInfo().concat(vu.getMessage()));
				message.setFlag(false);
				rd = request.getRequestDispatcher("SignIn.jsp");
				rd.forward(request, response);
				return;
			}
		}
		// if currentFlag is true, that means all the parameters have been validated.
				if (message.isFlag()) {
					UserServiceI userservice = new UserServiceImpl();
					User user = new User();
					user.setUsername(username);
					user.setPassword(password);
					message=userservice.signIn(user);	
					if(message.isFlag()) {
						User user1 = userservice.findByName("username");
						session.setAttribute("user",user1);
						session.setAttribute("message", message);
						rd = request.getRequestDispatcher("index.jsp");
						rd.forward(request, response);
					}else {
						session.setAttribute("message", message);
						rd = request.getRequestDispatcher("SignIn.jsp");
						rd.forward(request, response);
					}
						
						
					
				}
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
