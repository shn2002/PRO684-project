package ca.senecacollege.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ca.senecacollege.model.Claim;
import ca.senecacollege.model.Message;
import ca.senecacollege.model.Plan;
import ca.senecacollege.model.StatusType;
import ca.senecacollege.model.User;
import ca.senecacollege.service.ClaimServiceI;
import ca.senecacollege.service.PlanServiceI;
import ca.senecacollege.service.UserServiceI;
import ca.senecacollege.service.impl.ClaimServiceImpl;
import ca.senecacollege.service.impl.PlanServiceImpl;
import ca.senecacollege.service.impl.UserServiceImpl;
import ca.senecacollege.util.SessionUtil;
import ca.senecacollege.util.ValidationUtil;

/**
 * Servlet implementation class UpdateClaim
 */
@WebServlet("/UpdateClaim")
public class UpdateClaim extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateClaim() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		new SessionUtil().loginCheck(request, response, session);
		
		Message message = new Message(true,"");
		User user = (User)session.getAttribute("user");
		RequestDispatcher rd;
		
			String id = request.getParameter("id");
			String claimdate = request.getParameter("claimdate");
			String planid = request.getParameter("planid");
			String detaildesc = request.getParameter("detaildesc");
			String incident = request.getParameter("incident");
			String cstatus = request.getParameter("cstatus");
			
			List<ValidationUtil> vus = new ArrayList<ValidationUtil>();
			ValidationUtil vu1= new ValidationUtil().intVal("Claim Id", id);
			ValidationUtil vu2= new ValidationUtil().dateVal("Claim Date", claimdate);
			ValidationUtil vu3= new ValidationUtil().intVal("Plan Name", planid);
			ValidationUtil vu4= new ValidationUtil().stringVal("Detaildesc", detaildesc);
			ValidationUtil vu5= new ValidationUtil().stringVal("Incident", incident);
			ValidationUtil vu6= new ValidationUtil().intVal("Status", cstatus);
			vus.add(vu1);
			vus.add(vu2);
			vus.add(vu3);
			vus.add(vu4);
			vus.add(vu5);
			
			for (ValidationUtil vu: vus) {
				if(!vu.isFlag()) {
					message.setInfo(message.getInfo().concat(vu.getMessage()));
					message.setFlag(false);
					session.removeAttribute("message");
					session.setAttribute("message", message);
					rd = request.getRequestDispatcher("claims.jsp");
					rd.forward(request, response);
					return;
				}
			}
			
			if (message.isFlag()) {
				UserServiceI userservice = new UserServiceImpl();
				ClaimServiceI claimservice = new ClaimServiceImpl();
				Claim claim = claimservice.findById(vu1.getNumber(), user);
				PlanServiceI planservice = new PlanServiceImpl();
				List<Plan> plans =planservice.findAll(user);
				Plan plan = planservice.findById(vu3.getNumber(), user);
				claim.setClaimdate(vu2.getDate());
				claim.setIncident(incident);
				claim.setDetaildesc(detaildesc);
				claim.setPlan(plan);
				claim.setCstatus(StatusType.class.getEnumConstants()[vu6.getNumber()]);

				message=claimservice.update(claim, user);
				session.removeAttribute("message");
				session.setAttribute("message", message);
				session.removeAttribute("plans");
				session.setAttribute("plans", plans);
				List<User>users=userservice.findAll(user);
				session.setAttribute("users", users);
				rd = request.getRequestDispatcher("claims.jsp");
				rd.forward(request, response);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
