package ca.senecacollege.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ca.senecacollege.model.Message;
import ca.senecacollege.model.Product;
import ca.senecacollege.model.User;
import ca.senecacollege.service.ProductServiceI;
import ca.senecacollege.service.impl.ProductServiceImpl;
import ca.senecacollege.util.SessionUtil;
import ca.senecacollege.util.ValidationUtil;

/**
 * Servlet implementation class AddProduct
 */
@WebServlet("/AddProduct")
public class AddProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		new SessionUtil().loginCheck(request, response, session);
		
		Message message = new Message(true,"");
		User user = (User)session.getAttribute("user");
		RequestDispatcher rd;
		
			String productname = request.getParameter("productname");
			String serialnumber = request.getParameter("serialnumber");
			List<ValidationUtil> vus = new ArrayList<ValidationUtil>();
			ValidationUtil vu2= new ValidationUtil().stringVal("Product Name", productname);
			ValidationUtil vu3= new ValidationUtil().stringVal("Serial Number", serialnumber);
			vus.add(vu2);
			vus.add(vu3);
			
			for (ValidationUtil vu: vus) {
				if(!vu.isFlag()) {
					message.setInfo(message.getInfo().concat(vu.getMessage()));
					message.setFlag(false);
					session.removeAttribute("message");
					session.setAttribute("message", message);
					rd = request.getRequestDispatcher("products.jsp");
					rd.forward(request, response);
					return;
				}
			}
			
			if (message.isFlag()) {
				ProductServiceI productservice= new ProductServiceImpl();
				Product newProduct= new Product(0, productname,serialnumber);
				message=productservice.add(newProduct, user);
				session.removeAttribute("message");
				session.setAttribute("message", message);
				session.removeAttribute("products");
				List<Product>products=productservice.findAll();
				session.setAttribute("products", products);
				rd = request.getRequestDispatcher("products.jsp");
				rd.forward(request, response);
			}
			
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
