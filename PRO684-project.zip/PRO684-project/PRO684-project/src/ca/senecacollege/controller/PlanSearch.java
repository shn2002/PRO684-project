package ca.senecacollege.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ca.senecacollege.model.Message;
import ca.senecacollege.model.Plan;
import ca.senecacollege.model.User;
import ca.senecacollege.service.PlanServiceI;
import ca.senecacollege.service.impl.PlanServiceImpl;
import ca.senecacollege.util.SessionUtil;
import ca.senecacollege.util.ValidationUtil;

/**
 * Servlet implementation class PlanSearch
 */
@WebServlet("/PlanSearch")
public class PlanSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PlanSearch() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		new SessionUtil().loginCheck(request, response, session);
	
		Message message = new Message(true,"");
		String productname = request.getParameter("productname");
		ValidationUtil vu2= new ValidationUtil().stringVal("productname", productname);
		User user = (User)session.getAttribute("user");
		PlanServiceI planservice= new PlanServiceImpl();
		List<Plan> plans = null;
		if(!vu2.isFlag()) {
			// search all the user
			plans =planservice.findAll(user);
		}else {
			plans =planservice.search(productname, user);
			
		}
		session.setAttribute("plans", plans);
		message.setFlag(true);
		message.setInfo("search successfully");
		session.setAttribute("message", message);
		RequestDispatcher rd = request.getRequestDispatcher("plansearch.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
