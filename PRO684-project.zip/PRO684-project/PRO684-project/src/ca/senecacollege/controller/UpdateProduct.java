package ca.senecacollege.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ca.senecacollege.model.Message;
import ca.senecacollege.model.Product;
import ca.senecacollege.model.User;
import ca.senecacollege.service.ProductServiceI;
import ca.senecacollege.service.impl.ProductServiceImpl;
import ca.senecacollege.util.SessionUtil;
import ca.senecacollege.util.ValidationUtil;

/**
 * Servlet implementation class UpdateProduct
 */
@WebServlet("/UpdateProduct")
public class UpdateProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		new SessionUtil().loginCheck(request, response, session);
		
		Message message = new Message(true,"");
		User user = (User)session.getAttribute("user");
		RequestDispatcher rd;
		
			String id = request.getParameter("id");
			String productname = request.getParameter("productname");
			String serialnumber = request.getParameter("serialnumber");
;
			List<ValidationUtil> vus = new ArrayList<ValidationUtil>();
			ValidationUtil vu1= new ValidationUtil().intVal("Product ID", id);
			ValidationUtil vu2= new ValidationUtil().stringVal("Product Name", productname);
			ValidationUtil vu3= new ValidationUtil().stringVal("Serial Number", serialnumber);
			vus.add(vu1);
			vus.add(vu2);
			vus.add(vu3);
			
			for (ValidationUtil vu: vus) {
				if(!vu.isFlag()) {
					message.setInfo(message.getInfo().concat(vu.getMessage()));
					message.setFlag(false);
					session.removeAttribute("message");
					session.setAttribute("message", message);
					rd = request.getRequestDispatcher("products.jsp");
					rd.forward(request, response);
					return;
				}
			}
			
			if (message.isFlag()) {
				ProductServiceI productservice= new ProductServiceImpl();
				Product updateproduct= productservice.findById(vu1.getNumber());
				updateproduct.setProductname(productname);
				updateproduct.setSerialnumber(serialnumber);
				message=productservice.update(updateproduct, user);
				session.removeAttribute("message");
				session.setAttribute("message", message);
				session.removeAttribute("products");
				List<Product>products=productservice.findAll();
				session.setAttribute("products", products);
				rd = request.getRequestDispatcher("products.jsp");
				rd.forward(request, response);
			}
			
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
