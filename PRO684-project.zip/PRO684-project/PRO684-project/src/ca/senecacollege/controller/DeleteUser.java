package ca.senecacollege.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ca.senecacollege.model.Message;
import ca.senecacollege.model.User;
import ca.senecacollege.service.UserServiceI;
import ca.senecacollege.service.impl.UserServiceImpl;
import ca.senecacollege.util.SessionUtil;
import ca.senecacollege.util.ValidationUtil;

/**
 * Servlet implementation class DeleteUser
 */
@WebServlet("/DeleteUser")
public class DeleteUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		new SessionUtil().loginCheck(request, response, session);
		
		Message message = new Message(true,"");
		User user = (User)session.getAttribute("user");
			String id = request.getParameter("id");
			List<ValidationUtil> vus = new ArrayList<ValidationUtil>();
			ValidationUtil vu1= new ValidationUtil().intVal("User ID", id);
			vus.add(vu1);
			
			for (ValidationUtil vu: vus) {
				if(!vu.isFlag()) {
					message.setInfo(message.getInfo().concat(vu.getMessage()));
					message.setFlag(false);
					session.removeAttribute("message");
					session.setAttribute("message", message);
				}
			}
			if (message.isFlag()) {
				UserServiceI userservice= new UserServiceImpl();
				message=userservice.deleteUser(vu1.getNumber(), user);
				session.removeAttribute("message");
				session.setAttribute("message", message);
				session.removeAttribute("products");
				List<User>users=userservice.findAll(user);
				session.setAttribute("users", users);
			}
			RequestDispatcher rd = request.getRequestDispatcher("users.jsp");
			rd.forward(request, response);
			
		}
			

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
